even_length([_]).
even_length([_|T]):- odd_length(T).
odd_length([_]).
odd_length([_|T]):- even_length(T).
