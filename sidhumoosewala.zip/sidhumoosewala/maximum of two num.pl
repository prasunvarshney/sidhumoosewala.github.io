max(X, Y, M) :- X>Y, M is X.
max(_, Y, M) :- M is Y.
